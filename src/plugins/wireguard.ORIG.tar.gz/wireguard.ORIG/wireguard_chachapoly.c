/* SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2022 Rubicon Communications, LLC.
 * Copyright (c) 2026 Cisco and/or its affiliates.
 */

#include <wireguard/wireguard.h>
#include <wireguard/wireguard_chachapoly.h>
#include <wireguard/wireguard_hchacha20.h>

bool
wg_chacha20poly1305_calc (vlib_main_t *vm, u8 *src, u32 src_len, u8 *dst, u8 *aad, u32 aad_len,
			  u64 nonce, vnet_crypto_op_type_t type, vnet_crypto_ctx_t *ctx)
{
  vnet_crypto_op_t _op, *op = &_op;
  u8 iv[12];
  u8 tag_[NOISE_AUTHTAG_LEN] = {};
  u8 src_[] = {};

  clib_memset (iv, 0, 12);
  clib_memcpy (iv + 4, &nonce, sizeof (nonce));

  vnet_crypto_op_init (ctx, op);
  op->type = type;

  op->auth_len = NOISE_AUTHTAG_LEN;
  if (type == VNET_CRYPTO_OP_TYPE_DECRYPT)
    {
      op->auth = src + src_len - NOISE_AUTHTAG_LEN;
      src_len -= NOISE_AUTHTAG_LEN;
      op->flags |= VNET_CRYPTO_OP_FLAG_HMAC_CHECK;
    }
  else
    op->auth = tag_;

  op->src = !src ? src_ : src;
  op->len = src_len;

  op->dst = dst;
  op->aad = aad;
  op->aad_len = aad_len;
  op->iv = iv;

  vnet_crypto_process_ops (vm, op, 0, 1);
  if (type == VNET_CRYPTO_OP_TYPE_ENCRYPT)
    {
      clib_memcpy (dst + src_len, op->auth, NOISE_AUTHTAG_LEN);
    }

  return (op->status == VNET_CRYPTO_OP_STATUS_COMPLETED);
}

void
wg_xchacha20poly1305_encrypt (vlib_main_t *vm, u8 *src, u32 src_len, u8 *dst,
			      u8 *aad, u32 aad_len,
			      u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
			      u8 key[CHACHA20POLY1305_KEY_SIZE])
{
  int i;
  u32 derived_key[CHACHA20POLY1305_KEY_SIZE / sizeof (u32)];
  u64 h_nonce;
  vnet_crypto_ctx_t *ctx;

  clib_memcpy (&h_nonce, nonce + 16, sizeof (h_nonce));
  h_nonce = clib_little_to_host_u64 (h_nonce);
  hchacha20 (derived_key, nonce, key);

  for (i = 0; i < (sizeof (derived_key) / sizeof (derived_key[0])); i++)
    (derived_key[i]) = clib_host_to_little_u32 ((derived_key[i]));
  ctx = vnet_crypto_ctx_create (VNET_CRYPTO_ALG_CHACHA20_POLY1305);
  if (ctx)
    vnet_crypto_ctx_set_cipher_key (ctx, (u8 *) derived_key, CHACHA20POLY1305_KEY_SIZE);

  wg_chacha20poly1305_calc (vm, src, src_len, dst, aad, aad_len, h_nonce,
			    VNET_CRYPTO_OP_TYPE_ENCRYPT, ctx);

  vnet_crypto_ctx_destroy (vm, ctx);
  wg_secure_zero_memory (derived_key, CHACHA20POLY1305_KEY_SIZE);
}

bool
wg_xchacha20poly1305_decrypt (vlib_main_t *vm, u8 *src, u32 src_len, u8 *dst,
			      u8 *aad, u32 aad_len,
			      u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
			      u8 key[CHACHA20POLY1305_KEY_SIZE])
{
  int ret, i;
  u32 derived_key[CHACHA20POLY1305_KEY_SIZE / sizeof (u32)];
  u64 h_nonce;
  vnet_crypto_ctx_t *ctx;

  clib_memcpy (&h_nonce, nonce + 16, sizeof (h_nonce));
  h_nonce = clib_little_to_host_u64 (h_nonce);
  hchacha20 (derived_key, nonce, key);

  for (i = 0; i < (sizeof (derived_key) / sizeof (derived_key[0])); i++)
    (derived_key[i]) = clib_host_to_little_u32 ((derived_key[i]));
  ctx = vnet_crypto_ctx_create (VNET_CRYPTO_ALG_CHACHA20_POLY1305);
  if (ctx)
    vnet_crypto_ctx_set_cipher_key (ctx, (u8 *) derived_key, CHACHA20POLY1305_KEY_SIZE);

  ret = wg_chacha20poly1305_calc (vm, src, src_len, dst, aad, aad_len, h_nonce,
				  VNET_CRYPTO_OP_TYPE_DECRYPT, ctx);

  vnet_crypto_ctx_destroy (vm, ctx);
  wg_secure_zero_memory (derived_key, CHACHA20POLY1305_KEY_SIZE);

  return ret;
}
